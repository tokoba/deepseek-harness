/**
 * [dsh-hardened] In-source outbound filter for DeepSeek provider packages.
 *
 * apply-hardening.ts copies this file into
 *   packages/llm/llm-deepseek/src/hardened-fetch.ts
 *   packages/web/web-deepseek-api/src/hardened-fetch.ts   (when present)
 * and rewrites every bare `fetch(` call in those packages to `hardenedFetch(`.
 *
 * Guarantees (independent of plugin config, UI switches, HMR or profile patches):
 *   - top-level `dsh_*` request fields are removed (dsh_session_log, dsh_plugin_packages, future dsh_* fields)
 *   - `x-deepseek-harness-*` headers are removed (user-id, session-id, compact)
 *   - *.deepseeksvc.com is never contacted
 * Opt back in per item (all default OFF):
 *   DSH_HARDENED_ALLOW_SESSION_LOG_UPLOAD=1   keep dsh_session_log
 *   DSH_HARDENED_ALLOW_PLUGIN_INVENTORY=1     keep dsh_plugin_packages
 *   DSH_HARDENED_ALLOW_SESSION_HEADER=1       keep x-deepseek-harness-session-id (official api.deepseek.com only)
 */

const DENY_SUFFIX = 'deepseeksvc.com'
const OFFICIAL_HOSTS = new Set(['api.deepseek.com'])

function allowedBodyKey(key: string): boolean {
  if (!key.startsWith('dsh_')) return true
  if (key === 'dsh_session_log') return process.env.DSH_HARDENED_ALLOW_SESSION_LOG_UPLOAD === '1'
  if (key === 'dsh_plugin_packages') return process.env.DSH_HARDENED_ALLOW_PLUGIN_INVENTORY === '1'
  return false // unknown future dsh_* fields: fail closed
}

function sanitizeHeaders(headers: Headers, host: string): void {
  for (const name of [...headers.keys()]) {
    const n = name.toLowerCase()
    if (!n.startsWith('x-deepseek-harness-')) continue
    const keep = n === 'x-deepseek-harness-session-id' &&
      process.env.DSH_HARDENED_ALLOW_SESSION_HEADER === '1' &&
      OFFICIAL_HOSTS.has(host)
    if (!keep) headers.delete(name)
  }
}

function sanitizeBody(body: unknown, headers: Headers): unknown {
  if (typeof body !== 'string') return body // Files API multipart / streams pass through untouched
  const head = body.trimStart()
  if (!head.startsWith('{')) return body
  let parsed: unknown
  try {
    parsed = JSON.parse(body)
  } catch {
    return body
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) return body
  const obj = parsed as Record<string, unknown>
  let changed = false
  for (const key of Object.keys(obj)) {
    if (!allowedBodyKey(key)) {
      delete obj[key]
      changed = true
    }
  }
  if (!changed) return body
  headers.delete('content-length')
  return JSON.stringify(obj)
}

export async function hardenedFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const href = input instanceof Request ? input.url : input instanceof URL ? input.href : String(input)
  const url = new URL(href)
  const host = url.hostname.toLowerCase()
  if (host === DENY_SUFFIX || host.endsWith('.' + DENY_SUFFIX)) {
    throw new TypeError('fetch failed', { cause: new Error(`[dsh-hardened] blocked ${host}`) })
  }
  if (input instanceof Request) {
    // Adapter code passes (url, init); a Request object is handled conservatively by re-materialising it.
    const headers = new Headers(input.headers)
    if (init?.headers) new Headers(init.headers).forEach((v, k) => headers.set(k, v))
    sanitizeHeaders(headers, host)
    const raw = init?.body !== undefined ? init.body : input.body === null ? undefined : await input.clone().text()
    const body = sanitizeBody(raw, headers)
    return fetch(url.href, { ...init, method: init?.method ?? input.method, signal: init?.signal ?? input.signal, headers, body: body as BodyInit | undefined })
  }
  const headers = new Headers(init?.headers)
  sanitizeHeaders(headers, host)
  const body = sanitizeBody(init?.body, headers)
  return fetch(input, { ...init, headers, body: body as BodyInit | null | undefined })
}
